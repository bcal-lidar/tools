BCAL LiDAR Tools ver 1.5.3 (2/03/2014 01:25PM MT)


Installation:
-------------

1) Download the Lidar Tools Zip file. Unzip the file in the "save_add" folder of your ENVI installation. On my computer, this folder is located at: "C:\Program Files\ITT\IDL71\products\envi47\save_add\". If you have previous versions installed, remove the previous versions.
2) Start ENVI


Usage:
------

Read online help at: http://code.google.com/p/bcal-lidar-tools/wiki/TableOfContents
